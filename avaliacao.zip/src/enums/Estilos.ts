export enum Estilos {
    ArtDeco = 'ArtDeco',
    Vitoriano = 'Vitoriano',
    Moderno = 'Moderno'
  }
  