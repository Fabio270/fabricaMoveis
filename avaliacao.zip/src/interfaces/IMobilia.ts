export interface IMobilia {
    estilo: string;
    descricao(): string;
  }  