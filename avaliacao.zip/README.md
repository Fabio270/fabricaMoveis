# fabricaMoveis
# rode npm install
# depois rode npm start